import React,{Component} from 'react';
import './App.css';

export class ABOUT extends Component{
    render(){
        const myStyle={
            // backgroundImage:
            // "url('https://image.shutterstock.com/image-vector/furniture-logo-template-260nw-372220771.jpg')",
            height: '77vh',
            width: '208vh',
            marginLeft:2,
            fontSize:'20px',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            backgroundColor:'#a9a9a9',
        };
        
        return(
            <div style={myStyle}>
               {/* <div  style={myStyle}> </div> */}
                 <div style={{marginTop:10}}>
                <img src="https://img.freepik.com/premium-vector/minimalist-furniture-logo-background_23-2148460878.jpg?w=2000" height= "300" width= "500" marginLeft="10"/>

            </div>
                     <h4 style={{marginLeft:700, margin:60}}>FURNITURES is a global leader in life at home. Founded in Sweden in 1943, FURNITURES is now a worldwide retailer of affordable, well-designed products and solutions for every room in your home. Our values and optimism are shared with millions of co-workers and customers around the world. Along with our desire to champion sustainable living, responsible sourcing, and communities in need of support.</h4> 
                          
                </div>
        )           
        
}
}
