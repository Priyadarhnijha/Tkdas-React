import React,{Component} from 'react';
import {NavLink} from 'react-router-dom';
import {Navbar,Nav} from 'react-bootstrap';
import Marquee from "react-fast-marquee";


// import {Dropdown} from 'react-bootstrap';

export class Navigation extends Component{
    render(){
        return(

            <Navbar bg="light" expand="lg">
            <Navbar.Toggle aria-controls="basic-navbar-nav"/>
            <Navbar.Collapse id="basic-navbar-nav">
            <Nav>
                <div style={{backgroundColor:"#FC702B ", padding:5}}>
                <Marquee speed={70}>
                <NavLink className="d-inline p-2 bg-light text-black" style={{color: "white", fontWeight: 'bold' , textDecoration:'none' , fontSize:25, marginRight:100}}>
                    GOOD FOOD GOOD LIFE
                </NavLink>
                </Marquee>

                <NavLink className="d-inline p-2 bg-light text-black" style={{color: "white", fontWeight: 'bold' ,textDecoration:'none' , fontSize:20, marginLeft:1000, padding:2}} to="/About">
                    About Us
                </NavLink>

                <NavLink className="d-inline p-2 bg-light text-black" style={{color: "white", fontWeight: 'bold' , textDecoration:'none' , fontSize:20, marginLeft:20, padding:2}} to="/FAQS">
                    FAQ
                </NavLink>

                {/* <NavLink className="d-inline p-2 bg-light text-black" style={{color: "#81064F", fontWeight: 'bold' , textDecoration:'none' , fontSize:20, marginLeft:20, border:'2px solid black', padding:2}}>
                {/* <select> */}
                {/* <option value="starter">Starter</option>
                  <option value="maincourse">Main Course</option>
                  <option value="sweets">Sweets</option>
                  <option value="drinks">Drinks</option>
                  <option value="mineralwater">Mineral Water</option>
                </select> */} 
                {/* </NavLink> */}

                {/* <Dropdown>
                    <Dropdown.Toggle variant="success" className="d-inline p-2 bg-light text-black dropdown-basic" style={{color: "#81064F", backgroundColor:'white',fontWeight: 'bold' , marginLeft:15, color:'black',border:'2px solid black', padding:2}}>
                      MENU
                    </Dropdown.Toggle>
                    
                     
                   <Dropdown.Menu  variant="success" id="dropdown-basic" style={{fontWeight: 'bold' , marginLeft:10, border:'2px solid black'}}>
                      <Dropdown.Item href="/Starter">Starter</Dropdown.Item>
                      <Dropdown.Item href="/Main Course">Main Course</Dropdown.Item>
                      <Dropdown.Item href="/Sweets">Sweets</Dropdown.Item>
                      <Dropdown.Item href="/Drinks">Drinks</Dropdown.Item>
                      
                    </Dropdown.Menu>
                  </Dropdown> */}
                </div>

                


            </Nav>
            </Navbar.Collapse>
        </Navbar>
        
        );
    }
}
