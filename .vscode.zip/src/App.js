import React from 'react';
import './App.css';

import {Home} from './Home';
// import {Products} from './Products';
// import {Orders} from './Orders';
// import {Transactions} from './Transactions';


import {Navigation} from './Navigation';
// //import { AdminNavigation } from './Admin/AdminNavigation';
import {BrowserRouter, Route,Routes, Link} from 'react-router-dom';







function App() {
  return (
    
    <BrowserRouter>
    <div className="App">
    <h2 className="m-3 d-flex justify-content-center text-white " style={{color:"white",backgroundColor: 'black',fontWeight: 'bold'}}>
       USER DASHBOARD 
    </h2>

    <Navigation/>       
    <Routes>
      <Route path='/' element={<Home/>} exact />
    </Routes>
    
      
    </div>
    {/* <Footer /> */}
    </BrowserRouter>
    
  );
}

export default App;
